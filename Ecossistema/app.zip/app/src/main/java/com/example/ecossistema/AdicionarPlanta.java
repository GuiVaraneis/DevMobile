package com.example.ecossistema;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

public class AdicionarPlanta extends Activity {

    private static final int REQUEST_CODE_GALERIA = 1;

    private EditText campoNome, campoData;
    private Spinner campoTipo;
    private ImageView categoryImage;
    private Button buttonSalvar;

    private ArrayList<Planta> listaPlantas;
    private String imagemSelecionadaPath = ""; // Armazenar o caminho da imagem

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adicionar_plantas);

        // Inicializando os componentes do layout
        campoNome = findViewById(R.id.campoNome);
        campoData = findViewById(R.id.campoData);
        campoTipo = findViewById(R.id.campoTipo);
        categoryImage = findViewById(R.id.categoryImage);
        buttonSalvar = findViewById(R.id.buttonsalvar);

        // Carregar a lista de plantas
        listaPlantas = carregarPlantas();

        // Configurar o Spinner com os tipos de plantas
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.tipo_plantas,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        campoTipo.setAdapter(adapter);

        // Configurar o evento de seleção do Spinner
        campoTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String tipoSelecionado = parent.getItemAtPosition(position).toString();

                // Alterar a imagem de acordo com o tipo selecionado
                switch (tipoSelecionado) {
                    case "Hortaliças":
                        categoryImage.setImageResource(R.drawable.img_hortalica);
                        break;
                    case "Ervas":
                        categoryImage.setImageResource(R.drawable.img_ervas);
                        break;
                    case "Flores":
                        categoryImage.setImageResource(R.drawable.img_flores);
                        break;
                    case "Suculentas":
                        categoryImage.setImageResource(R.drawable.img_suculenta);
                        break;
                    default:
                        categoryImage.setImageResource(android.R.color.transparent);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Não faz nada se nada for selecionado
            }
        });

        // Configurar o evento de salvar
        buttonSalvar.setOnClickListener(v -> {
            String nome = campoNome.getText().toString();
            String data = campoData.getText().toString();
            String tipo = campoTipo.getSelectedItem().toString();

            // Verificar se todos os campos foram preenchidos
            if (nome.isEmpty() || data.isEmpty() || imagemSelecionadaPath.isEmpty()) {
                Toast.makeText(AdicionarPlanta.this, "Preencha todos os campos e selecione uma imagem!", Toast.LENGTH_SHORT).show();
            } else {
                // Criar um novo objeto Planta
                Planta novaPlanta = new Planta(nome, data, tipo, imagemSelecionadaPath);
                listaPlantas.add(novaPlanta);

                // Salvar as plantas usando SharedPreferences
                salvarPlantas(listaPlantas);

                // Mostrar uma mensagem de sucesso
                Toast.makeText(AdicionarPlanta.this, "Planta adicionada com sucesso!", Toast.LENGTH_SHORT).show();

                // Limpar os campos
                campoNome.setText("");
                campoData.setText("");
                categoryImage.setImageResource(android.R.color.transparent);
                imagemSelecionadaPath = ""; // Limpar a imagem
            }
        });
    }

    // Método para salvar a lista de plantas no SharedPreferences
    private void salvarPlantas(ArrayList<Planta> plantas) {
        SharedPreferences sharedPreferences = getSharedPreferences("Plantas", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Converter a lista de plantas para JSON
        Gson gson = new Gson();
        String plantasJson = gson.toJson(plantas);

        // Salvar o JSON na SharedPreferences
        editor.putString("ListaPlantas", plantasJson);
        editor.apply();
    }

    // Método para carregar a lista de plantas do SharedPreferences
    private ArrayList<Planta> carregarPlantas() {
        SharedPreferences sharedPreferences = getSharedPreferences("Plantas", MODE_PRIVATE);
        String plantasJson = sharedPreferences.getString("ListaPlantas", null);

        if (plantasJson == null) {
            return new ArrayList<>(); // Retorna uma lista vazia caso não haja plantas salvas
        } else {
            Gson gson = new Gson();
            Planta[] plantasArray = gson.fromJson(plantasJson, Planta[].class);
            ArrayList<Planta> plantasList = new ArrayList<>();
            for (Planta planta : plantasArray) {
                plantasList.add(planta);
            }
            return plantasList;
        }
    }


    }

