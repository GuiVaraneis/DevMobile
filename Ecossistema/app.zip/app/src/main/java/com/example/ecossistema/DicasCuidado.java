package com.example.ecossistema;

import android.app.Activity;

public class DicasCuidado extends Activity {
}
