package com.example.ecossistema;

    public class Planta {
        private String nome;
        private String data;
        private String tipo;
        private String imagemPath;

        public Planta(String nome, String data, String tipo, String imagemPath) {
            this.nome = nome;
            this.data = data;
            this.tipo = tipo;
            this.imagemPath = imagemPath;
        }

        public String getNome() {
            return nome;
        }

        public String getData() {
            return data;
        }

        public String getTipo() {
            return tipo;
        }

        public String getImagemPath() {
            return imagemPath;
        }
    }


